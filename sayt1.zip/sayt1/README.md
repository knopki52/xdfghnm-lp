# MediNow — UI mockup

A static Flutter recreation of the MediNow "Meditate With Us" onboarding
screen, built purely to study core Flutter UI elements (Scaffold, SafeArea,
Column/Row, Stack/Positioned, gradients, custom "pill" buttons, icons).

**There is no functionality behind any button** — this is a design/layout
exercise only, not a working app.

## Getting started (VS Code)

1. Open this folder in VS Code (with the Flutter/Dart extensions installed).
2. Run `flutter pub get` (VS Code usually does this automatically) to fetch
   the `google_fonts` dependency.
3. Pick a run target from the device selector at the bottom-right:
   - an iOS Simulator, or
   - "Open in Xcode" — right-click `ios/Runner.xcworkspace` in Finder and
     choose "Open With > Xcode", or run `open ios/Runner.xcworkspace` from
     a terminal in this folder.
4. Run the app (`F5` in VS Code, or the Run button in Xcode) to see the
   screen on a simulator/device.

All of the UI lives in `lib/main.dart`.
