import 'package:flutter/material.dart';

void main() {
  runApp(const MedinowApp());
}

class MedinowApp extends StatelessWidget {
  const MedinowApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LoginScreen(),
    );
  }
}

class AppColors {
  static const bg = Color(0xFF4A9691);
  static const pill = Color(0xFFD6EEF0);
  static const badge = Color(0xFF4A2E22);
  static const mat = Color(0xFF356E6A);
  static const person = Color(0xFF223238);
}

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28),
          child: Column(
            children: [
              const SizedBox(height: 28),
              const Text(
                'medinow',
                style: TextStyle(
                  fontSize: 34,
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                'Meditate With Us!',
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 48),
              authButton(
                label: 'Sign in with Apple',
                bg: Colors.white,
                fg: Colors.black,
                icon: Icons.apple,
              ),
              const SizedBox(height: 14),
              authButton(
                label: 'Continue with Email or Phone',
                bg: AppColors.pill,
                fg: Colors.black87,
              ),
              const SizedBox(height: 18),
              const Text(
                'Continue With Google',
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
              const Spacer(),
              const MeditationArt(),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }
}

Widget authButton({
  required String label,
  required Color bg,
  required Color fg,
  IconData? icon,
}) {
  return Container(
    width: double.infinity,
    height: 54,
    decoration: BoxDecoration(
      color: bg,
      borderRadius: BorderRadius.circular(27),
    ),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (icon != null) ...[
          Icon(icon, size: 20, color: fg),
          const SizedBox(width: 8),
        ],
        Text(
          label,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: fg,
          ),
        ),
      ],
    ),
  );
}

class MeditationArt extends StatelessWidget {
  const MeditationArt({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 220,
      width: double.infinity,
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          const Positioned(
            left: 0,
            bottom: 30,
            child: Icon(Icons.eco, size: 64, color: Colors.white24),
          ),
          const Positioned(
            right: 4,
            bottom: 60,
            child: Icon(Icons.eco, size: 48, color: Colors.white24),
          ),
          const Positioned(
            right: 40,
            bottom: 10,
            child: Icon(Icons.spa, size: 40, color: Colors.white24),
          ),
          Positioned(
            bottom: 8,
            child: Transform.rotate(
              angle: 0.785398,
              child: Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  color: AppColors.mat,
                  borderRadius: BorderRadius.circular(18),
                ),
              ),
            ),
          ),
          const Positioned(
            bottom: 24,
            child: Icon(Icons.self_improvement, size: 150, color: AppColors.person),
          ),
          Positioned(
            top: 4,
            right: 90,
            child: Container(
              width: 34,
              height: 34,
              decoration: const BoxDecoration(
                color: AppColors.badge,
                shape: BoxShape.circle,
              ),
              alignment: Alignment.center,
              child: const Icon(Icons.self_improvement, size: 18, color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}
