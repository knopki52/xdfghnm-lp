import 'package:flutter/material.dart';

void main() {
  runApp(const RelaxApp());
}

class RelaxApp extends StatelessWidget {
  const RelaxApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: SessionScreen(),
    );
  }
}

const kSand = Color(0xFFE4A93C);
const kPier = Color(0xFF394A5A);
const kTag = Color(0xFF4A2E22);
const kTeal = Color(0xFF3E8F87);
const kMuted = Color(0xFF8A8A8A);

class SessionScreen extends StatelessWidget {
  const SessionScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const CoverCard(),
            const SizedBox(height: 20),
            const Text(
              'Peter Mach',
              style: TextStyle(fontSize: 14, color: kMuted),
            ),
            const SizedBox(height: 6),
            const Text(
              'Mind Deep Relax',
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 10),
            const Text(
              'Join the Community as we prepare over 33 days to relax and feel joy with the mind and happines session across the World.',
              style: TextStyle(fontSize: 14, color: kMuted, height: 1.4),
            ),
            const SizedBox(height: 22),
            playNextButton(),
            const SizedBox(height: 22),
            sessionTile(
              color: const Color(0xFF3E5FCC),
              title: 'Sweet Memories',
              subtitle: 'December 29 Pre-Launch',
            ),
            const Divider(height: 32),
            sessionTile(
              color: kTeal,
              title: 'A Day Dream',
              subtitle: 'December 29 Pre-Launch',
            ),
            const Divider(height: 32),
            sessionTile(
              color: const Color(0xFFE08A2E),
              title: 'Mind Explore',
              subtitle: 'December 29 Pre-Launch',
            ),
          ],
        ),
      ),
    );
  }
}

class CoverCard extends StatelessWidget {
  const CoverCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 260,
      decoration: BoxDecoration(
        color: kSand,
        borderRadius: BorderRadius.circular(24),
      ),
      child: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          const Positioned(
            top: 20,
            left: 24,
            child: Icon(Icons.cloud, size: 28, color: Colors.white54),
          ),
          const Positioned(
            top: 40,
            right: 40,
            child: Icon(Icons.cloud, size: 22, color: Colors.white54),
          ),
          Positioned(
            bottom: 40,
            child: Container(
              width: 160,
              height: 14,
              decoration: BoxDecoration(
                color: kPier,
                borderRadius: BorderRadius.circular(4),
              ),
            ),
          ),
          const Positioned(
            bottom: 46,
            child: Icon(Icons.accessibility_new, size: 90, color: kPier),
          ),
          const Positioned(
            top: 30,
            child: TagBadge(),
          ),
        ],
      ),
    );
  }
}

class TagBadge extends StatelessWidget {
  const TagBadge({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 30,
      height: 30,
      decoration: const BoxDecoration(
        color: kTag,
        shape: BoxShape.circle,
      ),
      alignment: Alignment.center,
      child: const Text(
        'N',
        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
      ),
    );
  }
}

Widget playNextButton() {
  return Container(
    width: double.infinity,
    height: 54,
    decoration: BoxDecoration(
      color: kTeal,
      borderRadius: BorderRadius.circular(27),
    ),
    child: const Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(Icons.play_arrow, color: Colors.white),
        SizedBox(width: 8),
        Text(
          'Play Next Session',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
      ],
    ),
  );
}

Widget sessionTile({
  required Color color,
  required String title,
  required String subtitle,
}) {
  return Row(
    children: [
      Container(
        width: 48,
        height: 48,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(12),
        ),
        alignment: Alignment.center,
        child: const Icon(Icons.play_arrow, color: Colors.white),
      ),
      const SizedBox(width: 14),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              style: const TextStyle(fontSize: 13, color: kMuted),
            ),
          ],
        ),
      ),
      const Icon(Icons.more_horiz, color: kMuted),
    ],
  );
}
