package com.example.mind_deep_relax

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
