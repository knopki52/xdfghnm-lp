# Mind Deep Relax — UI mockup

Статичный макет на Flutter (без функциональности), сделан для изучения
базовых элементов интерфейса.

## Запуск

cd ~/dev/flutter_projects/mind_deep_relax
flutter pub get
flutter run
